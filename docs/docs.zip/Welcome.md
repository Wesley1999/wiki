# Welcome



欢迎来到我的Wiki，这里是我所有专业知识的笔记。
部分内容转载于网络，已尽可能标明出处。

<br>

请在左侧菜单中选择要查看的文档。

← ← ←

<br>

<img src=https://oss-pic.wangshaogang.com/1586691188494-a43c1772-3a65-4132-85b3-ced6746c30e9.png style='margin-right:10px; width: 22px'><a href='https://www.wangshaogang.com' target="1" rel="noopener noreferrer">https://www.wangshaogang.com</a>

<img src=https://oss-pic.wangshaogang.com/1586857333932-3086efcb-0ddc-4e72-ba34-e4cd99fcfb0d.png style='margin-right:10px; width: 22px'><a href='https://github.com/Wesley1999' target="1" rel="noopener noreferrer">https://github.com/Wesley1999</a>

<img src=https://oss-pic.wangshaogang.com/1586691188496-cbd2f61b-0abc-48f3-8402-3b56f6841020.png style='margin-right:10px; width: 22px'>a13207123727@gmail.com

<div style="width:fit-content" onmouseover="document.getElementById('wx').style.width='500px';"><img src=https://oss-pic.wangshaogang.com/1586691188497-689b229c-444a-46d5-946d-ceeeb62a2ba1.png style='margin-right:10px; width: 22px'>wsg1827</div>

<img id='wx' src=https://oss-pic.wangshaogang.com/1586691274026-8b003750-4bff-4911-9fba-76b70cf10abe.jpg style='width: 0' onclick="this.style.width='0'">
