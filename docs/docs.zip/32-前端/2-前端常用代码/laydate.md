# laydate

laydate是layui的一个独立模块，官方文档：[https://www.layui.com/laydate/](https://www.layui.com/laydate/)
引入laydate必须在layui之前