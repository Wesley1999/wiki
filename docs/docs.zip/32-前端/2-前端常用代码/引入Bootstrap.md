# 引入Bootstrap

引入BootStrap前要先引入jQuery
```html
<!--jQuery-->
<script src="jQuery/jquery-3.4.1.min.js"></script>
<!-- BootStrap -->
<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/bootstrap.min.js"></script>
```