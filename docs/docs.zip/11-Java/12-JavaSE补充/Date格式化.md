# Date格式化

```java
Date d = new Date();
SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
System.out.println(sdf.format(d));
```