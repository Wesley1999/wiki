# Java各版本新特征

![](https://oss-pic.wangshaogang.com/1586691968248-f0edc1c4-1dfa-423f-9af1-b93572e15362.png)