# 清理DNS缓存

查看DNS缓存
```
ipconfig/displaydns
```

清理DNS缓存
```
ipconfig/flushdns
```
