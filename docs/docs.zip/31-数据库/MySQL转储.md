# MySQL转储

[http://www.111com.net/database/mysql/33830.htm](http://www.111com.net/database/mysql/33830.htm)