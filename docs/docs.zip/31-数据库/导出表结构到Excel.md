# 导出表结构到Excel

参考

[https://blog.csdn.net/u013258447/article/details/81450423](https://blog.csdn.net/u013258447/article/details/81450423)
