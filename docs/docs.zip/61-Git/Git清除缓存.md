# Git清除缓存

```shell
git rm -r --cached .
```

更新.gitignore文件后要清除缓存