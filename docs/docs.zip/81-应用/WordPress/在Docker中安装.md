# 在Docker中安装

看这个吧
见Docker目录