# WordPress目录结构

参考
[https://zhuanlan.zhihu.com/p/60461351](https://zhuanlan.zhihu.com/p/60461351)