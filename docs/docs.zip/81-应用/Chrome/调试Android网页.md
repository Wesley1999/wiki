# 调试Android网页

手机要开启USB调试模式。

访问
```
chrome://inspect/#devices
```


