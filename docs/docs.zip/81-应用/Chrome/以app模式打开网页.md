# 以app模式打开网页

在快捷方式的“目标”后面加上：
```
 --app=[网址]
```
例如：
```
 --app=https://wiki.wangshaogang.com
```
![](https://oss-pic.wangshaogang.com/1586692079612-30a8677c-cee2-4276-9184-7b0a65ed8065.png)

打开后的效果：
![](https://oss-pic.wangshaogang.com/1586692079612-b7df638c-dc78-457b-8f47-6a179ff1b6be.png)

## Reference
[巧用Chrome的APP模式](https://sspai.com/post/47718)