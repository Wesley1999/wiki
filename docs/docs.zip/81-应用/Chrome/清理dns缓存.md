# 清理dns缓存

访问
`chrome://net-internals/#dns`
点击按钮
`Clear host cache`