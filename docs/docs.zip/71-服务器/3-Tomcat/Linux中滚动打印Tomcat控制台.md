# Linux中滚动打印Tomcat控制台

```shell
## cd tomcat/logs
tail -f catalina.out
```