# CentO7S挂载OneDrive

参考[在centos-7上使用rclone挂载onedrive网盘](https://www.centos.bz/2019/02/%E5%9C%A8centos-7%E4%B8%8A%E4%BD%BF%E7%94%A8rclone%E6%8C%82%E8%BD%BDonedrive%E7%BD%91%E7%9B%98/)