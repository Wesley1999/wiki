# VI编辑器

## 键盘图
![](https://oss-pic.wangshaogang.com/1586886853151-bd1bceec-38d0-48da-80d2-165959735394.png)

## 补充
```shell
:noh    取消搜索高亮
```