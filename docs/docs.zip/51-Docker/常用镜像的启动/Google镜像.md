# Google镜像

```shell
docker run --name google -p 10080:80 -d bohan/onemirror
```

